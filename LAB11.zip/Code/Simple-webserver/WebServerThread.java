import java.io.*;
import java.net.*;

class WebServerThread extends Thread
{
	private Socket dataSocket;
	private InputStream is;
   	private BufferedReader in;
	private OutputStream os;
   	private DataOutputStream out;  // Allows for any type of data (array of bytes)

   	public WebServerThread(Socket socket)
   	{
		dataSocket = socket;
		try {
			is = dataSocket.getInputStream();
			in = new BufferedReader(new InputStreamReader(is));
			os = dataSocket.getOutputStream();
			out = new DataOutputStream(os);
		}
		catch (IOException e)	{		
	 		System.out.println("I/O Error " + e);
		}
	}

	public void run()
	{
   		WebServerProtocol app = new WebServerProtocol();
		
		// There is no iteration, single stateless request-reply
		// in and out can be multiple lines, processed by the Protocol
        try {
            app.parseRequest(in);
            app.sendResponse(out);

            dataSocket.close();
        }    
        catch (IOException e)	{		
	 		System.out.println("I/O Error " + e);
		}
	}	
}	
			
		
